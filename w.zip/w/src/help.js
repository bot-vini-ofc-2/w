const help = (prefix) => {
	return `

    📕  BOT VINI COMANDOS 📕 :

 •━ ✽ • ✽ ━•【】•━ ✽ • ✽ ━•
 
 *DONO*: VINICIUS
 
 •━ ✽ • ✽ ━•【】•━ ✽ • ✽ ━•
 
 *WHATSAPP*: wa.me/5565992559365
 
 •━ ✽ • ✽ ━•【】•━ ✽ • ✽ ━•
 
 *GRUPO OFC*:  https://chat.whatsapp.com/GGHuaQQ5cZO7ibeBQjrEJA
 *GRUPO OTAKU*: https://chat.whatsapp.com/Kz48kM0vPAHFn4Cynk2W18
 
 •━ ✽ • ✽ ━•【】•━ ✽ • ✽ ━•


             MENU BOT VINI :


❚ ➣【MAIS USADOS】

❚ ➣${prefix}Sticker* [Faz figurinha]
❚ ➣${prefix}play* [nome da música]
❚ ➣${prefix}toimg* [converter figurinha em imagem]
❚ ➣${prefix}wame* [link do seu whatsapp]
❚ ➣${prefix}meme* [memes aleatórios]
❚ ➣${prefix}nabutojokes* [memes2]
❚ ➣${prefix}tts pt* [seu texto]
❚ ➣${prefix}ping* [velocidade]
❚ ➣${prefix}owner ou dono* [info do criador]

❚ ➣【RECÉM ADICIONADOS】

❚ ➣${prefix}animecry*
❚ ➣${prefix}chentai [premium]*
❚ ➣${prefix}gcpf [premium]*
❚ ➣${prefix}gay [@]*
❚ ➣${prefix}gbin [premium]*
❚ ➣${prefix}pack [premium]*
❚ ➣${prefix}destrava [premium]*
❚ ➣${prefix}gpessoa [premium]*
❚ ➣${prefix}spamcall*
❚ ➣${prefix}play (nome da msc)*

❚ ➣【COMANDOS DE GRUPO】

❚ ➣${prefix}closegc* [fechar grupo]
❚ ➣${prefix}opengc* [abrir grupo]
❚ ➣${prefix}antilink* 1 [anti link]
❚ ➣${prefix}antiracismo on* [anti racismo]
❚ ➣${prefix}banir* [banir membro]
❚ ➣${prefix}admins* [lista se administradores]
❚ ➣${prefix}marcar* [marcar todos membros]
❚ ➣${prefix}linkgp* [link do grupo]
❚ ➣${prefix}promover* [dar adm]
❚ ➣${prefix}rebaixar* [tirar adm]
❚ ➣${prefix}bemvindo* 1 [recusso de boas vindas]
❚ ➣${prefix}grupoinfo* [info]
❚ ➣${prefix}setdesc* [trocar descrição]
❚ ➣${prefix}setfoto* [mudar foto]
❚ ➣${prefix}porno* [porno]
❚ ➣${prefix}mia* [fotos da mia]

❚ ➣【INTERAÇÃO】

❚ ➣${prefix}figu*
❚ ➣${prefix}toimg*
❚ ➣${prefix}nabutojokes (memes aleatórios)*
❚ ➣${prefix}memeindo*
❚ ➣${prefix}tts*
❚ ➣${prefix}lolih [on]*
❚ ➣${prefix}nsfwloli [off]*
❚ ➣${prefix}url2img*
❚ ➣${prefix}leens [na legenda]*
❚ ➣${prefix}wait [na legenda]*
❚ ➣${prefix}setprefix*

❚ ➣【OUTROS COMANDOS】

❚ ➣${prefix}linkgp*
❚ ➣${prefix}simih [1/0]*
❚ ➣${prefix}marcar*
❚ ➣${prefix}add [@]*
❚ ➣${prefix}banir [@]*
❚ ➣${prefix}promover [@]*
❚ ➣${prefix}rebaixar*
❚ ➣${prefix}admins*
❚ ➣${prefix}marcar2*
❚ ➣${prefix}bc [texto]* (ele faz uma ™)
❚ ➣${prefix}marcar3*
❚ ➣${prefix}bloqueados*
❚ ➣${prefix}bloquear [@]*
❚ ➣${prefix}desbloquear [@]*
❚ ➣${prefix}limpar*
❚ ➣${prefix}bc [ *texto* ]*
❚ ➣${prefix}bemvindo [1/0]*
❚ ➣${prefix}clonar [@]*
❚ ➣${prefix}help1*
❚ ➣${prefix}dono*
❚ ➣${prefix}owner*
❚ ➣${prefix}tts [texto]*
❚ ➣${prefix}setnome*
❚ ➣${prefix}termux*
❚ ➣${prefix}setfoto*
❚ ➣${prefix}grupoinfo*
❚ ➣${prefix}ytmp4*
❚ ➣${prefix}bomdia*
❚ ➣${prefix}boanoite*
❚ ➣${prefix}marcar*
❚ ➣${prefix}marcar2*
❚ ➣${prefix}marcar3*

❚ ➣【 COMANDOS IMAGENS】

❚ ➣${prefix}loli* [off]
❚ ➣${prefix}loli1*
❚ ➣${prefix}hentai*
❚ ➣${prefix}dono*
❚ ➣${prefix}porno*
❚ ➣${prefix}boanoite*
❚ ➣${prefix}bomdia*
❚ ➣${prefix}boatarde*
❚ ➣${prefix}mia [aleatórias]*
❚ ➣${prefix}rize [aleatórias]*
❚ ➣${prefix}minato [aleatórias]*
❚ ➣${prefix}boruto [aleatórias]*
❚ ➣${prefix}hinata [aleatórias]*
❚ ➣${prefix}sasuke [aleatórias]*
❚ ➣${prefix}sakura [aleatórias]*
❚ ➣${prefix}naruto [aleatórias]*
❚ ➣${prefix}meme*   
❚ ➣${prefix}lofi*
❚ ➣${prefix}malkova*
❚ ➣${prefix}canal*
❚ ➣${prefix}nsfwloli1*
❚ ➣${prefix}reislin*

❚ ➣【 COMANDOS INTERATIVO】

❚ ➣${prefix}simih 1 (para ativar)*
❚ ➣${prefix}simih 0 (para desativar)*
❚ ➣${prefix}simi (sua mensagem)*

❚ ➣【COMANDOS PAGO】

❚ ➣${prefix}dado*
❚ ➣${prefix}cekvip*
❚ ➣${prefix}premiumlist*
❚ ➣${prefix}delete*
❚ ➣${prefix}modapk*
❚ ➣${prefix}indo10*
❚ ➣${prefix}daftarvip [para virar Premium]*
❚ ➣${prefix}qrcode*
❚ ➣${prefix}chentai*
❚ ➣${prefix}gcpf*
❚ ➣${prefix}gbin*
❚ ➣${prefix}pack*
❚ ➣${prefix}destrava*
❚ ➣${prefix}gpessoa*

❚ ➣【COMANDOS DE GRUPO 2】

❚ ➣${prefix}banir*
❚ ➣${prefix}leveling [on/off]*
❚ ➣${prefix}level*
❚ ➣${prefix}add*
❚ ➣${prefix}promover*
❚ ➣${prefix}setfoto [na legenda]*
❚ ➣${prefix}setname [texto]*
❚ ➣${prefix}rebaixar*
❚ ➣${prefix}admins*
❚ ➣${prefix}marcar*
❚ ➣${prefix}marcar2*
❚ ➣${prefix}marcar3*
❚ ➣${prefix}bemvindo [1/0]*
❚ ➣${prefix}grupoinfo*
❚ ➣${prefix}bomdia*
❚ ➣${prefix}boatarde*
❚ ➣${prefix}boanoite*
❚ ➣${prefix}setdesc*
❚ ➣${prefix}bug [sua mensagem]*

❚ ➣【EXCLUSIVOS DO BOT VINI】𝗹

❚ ➣${prefix}bug [sua mensagem]*
❚ ➣${prefix}clonar [@]*
❚ ➣${prefix}dono*
❚ ➣${prefix}ping [ver velocidade do bot]*
❚ ➣${prefix}termux*
❚ ➣${prefix}gay [@]*
❚ ➣${prefix}wame*
❚ ➣${prefix}map (nome)*
❚ ➣${prefix}setppbot (marque uma img)*
❚ ➣${prefix}pinterest (nome)*
❚ ➣${prefix}desligar (so para o dono)*
❚ ➣${prefix}timer*

❚ ➣【COMANDOS ALEATÓRIO】𝗹

❚ ➣${prefix}neko*
❚ ➣${prefix}ttp [texto]*
❚ ➣${prefix}testime*
❚ ➣${prefix}tomp3*
❚ ➣${prefix}modoanime [on/off]*
❚ ➣${prefix}modonsfw [on/off]*
❚ ➣${prefix}happymod [jogo/app]*
❚ ➣${prefix}rize*
❚ ➣${prefix}ytsearch*
❚ ➣${prefix}moddroid [jogo/app]*
❚ ➣${prefix}xvideos [titulo]**
❚ ➣${prefix}nomegp*
❚ ➣${prefix}nabutojokes (memes aleatórios)*
❚ ➣${prefix}animecry*
❚ ➣${prefix}gay1*
❚ ➣${prefix}next*
❚ ➣${prefix}alerta*
❚ ➣${prefix}belle [img aleatórias]*
❚ ➣${prefix}pronomeneu [texto]*
❚ ➣${prefix}hobby*

❚ ➣【 COMANDOS DE ÁUDIO】

❚ ➣${prefix} em teste
❚ ➣${prefix}jogaroxo*
❚ ➣${prefix} em teste
❚ ➣${prefix} em teste
❚ ➣${prefix}narutinho*
❚ ➣${prefix}}tobi*
❚ ➣${prefix}rapL*
❚ ➣${prefix}paypal*
❚ ➣${prefix}sad*

❚ ➣【 OUTROS COMANDOS /2 】

*❚ ➣*${prefix}antilink [1/0]*
*❚ ➣*${prefix}brainly [pergunta]*
❚ ➣${prefix}antiracismo [on/off]*
❚ ➣${prefix}setnomebot*
❚ ➣${prefix}meme*

❚ ➣【 COMANDOS INTELIGENTES】

NOTA »
Mandar a msg sem o prefixo


❚ ➣${prefix} *beat1*
❚ ➣${prefix} *beat2*
❚ ➣${prefix} *hentaisom* (erro)

❚ ➣【CRÉDITOS NABUTO】

 *𝗡𝗢𝗠𝗘: Vinicius 👇
 
 *𝗪𝗣𝗣: wa.me/+5565992559365




【 VINICIUS-BOT VINI】`
}

exports.help = help













