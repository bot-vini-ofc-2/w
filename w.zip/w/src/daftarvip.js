const daftarvip = (prefix) => { 
	return `
	
*PREÇO DE LISTA VIP DO BOT VINI :*

-Rp. 10 > Acessar recursos ViP do bot vini
-Rp. 20 > Recursos VIP + Insira o bot no seu grupo!

*SE QUER REGISTAR VIP :*

*Proprietário do bate-papo BOT :*

_wa.me/556592559365 ou digite *${prefix}owner*_

*NOTA*

*GRUPO DO BOT VINI:*
_https://chat.whatsapp.com/GGHuaQQ5cZO7ibeBQjrEJA `
}
exports.daftarvip = daftarvip
