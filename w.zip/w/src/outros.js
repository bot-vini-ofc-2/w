const iklan = () => { 
	return `           
╔══✪〘 *OUTROS* 〙✪══
║
╠➥ *${prefix}linkgp*
╠➥ *${prefix}simih [1/0]*
╠➥ *${prefix}marcar*
╠➥ *${prefix}add [@]*
╠➥ *${prefix}banir [@]*
╠➥ *${prefix}promover [@]*
╠➥ *${prefix}rebaixar*
╠➥ *${prefix}admins*
╠➥ *${prefix}marcar2*
╠➥ *${prefix}bc [texto]* (ele faz uma ™)
╠➥ *${prefix}marcar3*
╠➥ *${prefix}bloqueados*
╠➥ *${prefix}bloquear [@]*
╠➥ *${prefix}desbloquear [@]*
╠➥ *${prefix}limpar*
╠➥ *${prefix}bc [ *texto* ]*
╠➥ *${prefix}bemvindo [1/0]*
╠➥ *${prefix}clonar [@]*
╠➥ *${prefix}help1*
╠➥ *${prefix}dono*
╠➥ *${prefix}owner*
╠➥ *${prefix}tts [texto]*
╠➥ *${prefix}setnome*
╠➥ *${prefix}termux*
╠➥ *${prefix}setfoto*
╠➥ *${prefix}grupoinfo*
╠➥ *${prefix}ytmp4*
╠➥ *${prefix}bomdia*
╠➥ *${prefix}boanoite*
╠➸ *${prefix}marcar*
╠➸ *${prefix}marcar2*
╠➸ *${prefix}marcar3*
║
╚═〘  *BOT VINI* 〙
`
}
exports.iklan = iklan
