const cekvip = () => { 
	return `           
──────────────────
*Nome do bot* :  BOT VINI 
──────────────────
        『 *𝐕𝐈𝐏 𝐔𝐒𝐄𝐑* 』
──────────────────
• *Status*    : *ATIVO*
────────────────── 
*Status Bot:* *Online*
──────────────────

*AÍ SIM HEIN VOCÊ É UM MEMBRO VÍP, APROVEITE O BOT VINI😎✋`
}
exports.cekvip = cekvip
